# 🎨 Exemples d'Alertes Visuelles

## Exemple 1: Insider Très Probable (85%)

```
╔══════════════════════════════════════════════════════════════╗
║                  🚨 ALERTE INSIDER DÉTECTÉ                  ║
╚══════════════════════════════════════════════════════════════╝

Will Trump announce he's running for president in 2028?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Marché
[Voir sur Polymarket](https://polymarket.com/event/trump-2028)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎲 Probabilité Insider: 85%
████████░░ 🔥 TRÈS ÉLEVÉE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Recommandation              💰 Taille du pari
Suivre l'insider: YES ✅       $47,500

👤 Wallet                      📝 Premier trade?
0x1a2b3c...def456              ✅ OUI

⏰ Heure du trade
2025-11-04T02:15:33Z

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔍 Signaux détectés
• 🆕 Wallet créé spécifiquement pour ce trade
• 💰 Mise massive ($47,500)
• 🎯 100% focus sur ce marché uniquement
• ⏰ Trade à 2h (heures suspectes)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Polymarket Insider Detector • Données en temps réel

[📈 Voir le marché]
```

---

## Exemple 2: Insider Probable (72%)

```
╔══════════════════════════════════════════════════════════════╗
║                  🚨 ALERTE INSIDER DÉTECTÉ                  ║
╚══════════════════════════════════════════════════════════════╝

Will Apple announce a foldable iPhone in Q1 2026?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Marché
[Voir sur Polymarket](https://polymarket.com/event/apple-foldable)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎲 Probabilité Insider: 72%
███████░░░ ⚠️ ÉLEVÉE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Recommandation              💰 Taille du pari
Suivre l'insider: NO ❌        $23,800

👤 Wallet                      📝 Premier trade?
0x9f8e7d...abc123              ❌ Non (3 trades)

⏰ Heure du trade
2025-11-04T14:32:18Z

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔍 Signaux détectés
• 🆕 Wallet très récent (<5 trades)
• 💰 Grosse mise ($23,800)
• 🎯 Focus limité (3 marchés)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Polymarket Insider Detector • Données en temps réel

[📈 Voir le marché]
```

---

## Exemple 3: Insider Possible (58%)

```
╔══════════════════════════════════════════════════════════════╗
║                  🚨 ALERTE INSIDER DÉTECTÉ                  ║
╚══════════════════════════════════════════════════════════════╝

Will Bitcoin reach $150,000 by end of 2025?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Marché
[Voir sur Polymarket](https://polymarket.com/event/btc-150k)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎲 Probabilité Insider: 58%
█████░░░░░ ⚡ MOYENNE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Recommandation              💰 Taille du pari
Suivre l'insider: YES ✅       $12,400

👤 Wallet                      📝 Premier trade?
0x5c4d3e...xyz789              ❌ Non (8 trades)

⏰ Heure du trade
2025-11-04T09:47:52Z

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔍 Signaux détectés
• 🆕 Wallet récent (15 jours)
• 💰 Mise significative ($12,400)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Polymarket Insider Detector • Données en temps réel

[📈 Voir le marché]
```

---

## Code Couleur

| Probabilité | Couleur | Badge | Description |
|-------------|---------|-------|-------------|
| 80-100% | 🔴 Rouge | 🔥 TRÈS ÉLEVÉE | Wallet neuf + grosse mise + focus unique |
| 65-79% | 🟠 Orange | ⚠️ ÉLEVÉE | Plusieurs signaux forts |
| 50-64% | 🟡 Jaune | ⚡ MOYENNE | Quelques signaux suspects |
| 0-49% | ⚪ Gris | ℹ️ FAIBLE | Pas d'alerte envoyée |

---

## Jauge de Probabilité

```
100% : ██████████ 🔥 TRÈS ÉLEVÉE
 90% : █████████░ 🔥 TRÈS ÉLEVÉE
 80% : ████████░░ 🔥 TRÈS ÉLEVÉE
 70% : ███████░░░ ⚠️ ÉLEVÉE
 60% : ██████░░░░ ⚡ MOYENNE
 50% : █████░░░░░ ⚡ MOYENNE
 40% : ████░░░░░░ ℹ️ FAIBLE (pas d'alerte)
```

---

## Format Compact Mobile

Sur mobile, l'embed Discord s'adapte automatiquement:

```
🚨 ALERTE INSIDER
──────────────────
Will Trump run in 2028?

🎲 Probabilité: 85% 🔥

💡 Suivre: YES ✅
💰 Mise: $47,500
👤 Wallet: 0x1a2b...def
📝 Premier trade: ✅ OUI
⏰ 02:15:33Z

🔍 Signaux:
• Wallet neuf
• Mise massive
• Focus unique
• Heures suspectes

[Voir le marché →]
```
